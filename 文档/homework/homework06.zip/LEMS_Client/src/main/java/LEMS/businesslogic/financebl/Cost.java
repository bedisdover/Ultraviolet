package LEMS.businesslogic.financebl;

import LEMS.businesslogicservice.financeblservice.CostService;
import LEMS.vo.financevo.CostProfitVO;
import LEMS.vo.financevo.PayBillVO;

/**
 * @author 宋益明
 * 
 * 成本管理任务
 */
public class Cost implements CostService {

	public void payBill(PayBillVO pay) {
		// TODO Auto-generated method stub
		
	}

	public CostProfitVO costProfit(String date) {
		// TODO Auto-generated method stub
		return null;
	}

	public void costBenifitBill() {
		// TODO Auto-generated method stub
		
	}

}
