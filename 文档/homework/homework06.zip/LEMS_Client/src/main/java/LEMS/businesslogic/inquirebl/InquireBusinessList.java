package LEMS.businesslogic.inquirebl;

import LEMS.businesslogicservice.inquireblservice.InquireBusinessListService;
import LEMS.vo.inquirevo.BusinessListVO;

/**
 * @author 章承尧
 * inquireBusinessService接口的实现
 */
public class InquireBusinessList implements InquireBusinessListService {

	public BusinessListVO getBusinessList(String startTime, String endTime) {
		// TODO Auto-generated method stub
		return null;
	}

}
