package LEMS.presentation.orderui;

import javax.swing.JPanel;

/**
 * @author 宋益明
 * 
 * 派件任务界面
 */
public class SendingPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
