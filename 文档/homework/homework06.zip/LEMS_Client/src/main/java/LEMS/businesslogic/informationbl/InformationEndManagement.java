package LEMS.businesslogic.informationbl;

public class InformationEndManagement {

}
