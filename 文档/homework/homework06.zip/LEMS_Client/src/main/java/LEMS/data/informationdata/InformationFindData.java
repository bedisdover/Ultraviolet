package LEMS.data.informationdata;

import java.rmi.RemoteException;

import LEMS.po.informationpo.DriverPO;
import LEMS.po.informationpo.InstitutionPO;
import LEMS.po.informationpo.StuffPO;
import LEMS.po.informationpo.VehiclePO;

/**
 * @author 苏琰梓
 * InformationFind包数据
 * 2015年10月26日
 */
public class InformationFindData {
	public void findDriverPO(long id) throws RemoteException{
		
	}
	public void findVehiclePO(long id) throws RemoteException{
		
	}
	public void findInstitutionPO(String id) throws RemoteException{
		
	}
	public void findStuffPO(String id) throws RemoteException{
		
	}
}
