package LEMS.businesslogic.orderbl;

import LEMS.businesslogicservice.orderblservice.SendingService;
import LEMS.vo.ordervo.DeliveryVO;

/**
 * @author 宋益明
 * 
 * 派件任务
 */
public class Sending implements SendingService {

	public void addOrder(long id) {
		// TODO Auto-generated method stub
		
	}

	public void createDeliveryNote(DeliveryVO deliveryInfo) {
		// TODO Auto-generated method stub
		
	}

}
