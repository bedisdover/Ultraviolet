package LEMS.data.informationdata;

import java.rmi.RemoteException;

public class InformationFinishData {
	public void finish() throws RemoteException{
		
	}
}
