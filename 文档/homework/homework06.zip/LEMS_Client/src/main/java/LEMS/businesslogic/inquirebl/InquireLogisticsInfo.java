package LEMS.businesslogic.inquirebl;

import LEMS.businesslogicservice.inquireblservice.InquireLogisticsInfoService;
import LEMS.vo.inquirevo.LogisticsInfoVO;

/**
 * @author 章承尧
 * inquireLogisticsInfoService接口的实现
 */
public class InquireLogisticsInfo implements InquireLogisticsInfoService{

	public LogisticsInfoVO getInquireLogisticsInfo() {
		// TODO Auto-generated method stub
		return null;
	}

}
