package LEMS.businesslogic.informationbl;

public class InformationUpdate {

}
