package LEMS.businesslogic.orderbl;

import LEMS.businesslogicservice.orderblservice.AddOrderService;

/**
 * @author 宋益明
 *
 * 增加订单
 */
public class AddOrder implements AddOrderService{

	public void addOrder(long id) {
		// TODO Auto-generated method stub
		
	}

}
