package LEMS.businesslogic.financebl.stub;

import LEMS.businesslogicservice.financeblservice.NumericalStatementService;

/**
 * @author 宋益明
 * 
 * 统计报表任务桩程序
 */
public class NumericalStatementService_Stub implements NumericalStatementService {

	public void export(long id) {
		System.out.println("统计报表导出成功！\n");
	}

}
