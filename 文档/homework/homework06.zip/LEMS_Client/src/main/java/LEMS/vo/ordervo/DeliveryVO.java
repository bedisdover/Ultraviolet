package LEMS.vo.ordervo;

/**
 * @author 宋益明
 * 派件单值对象
 */
public class DeliveryVO {
	
}
