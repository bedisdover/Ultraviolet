package LEMS.data.orderdata;

import java.rmi.RemoteException;

import LEMS.dataservice.orderdataservice.OrderDataService;
import LEMS.po.orderpo.OrderPO;

/**
 * @author 宋益明
 * 
 * Order包数据
 */
public class OrderData implements OrderDataService {

	public OrderPO find(long id) throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	public void insert(OrderPO po) throws RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void delete(OrderPO po) throws RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void update(OrderPO po) throws RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void init() throws RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void finish() throws RemoteException {
		// TODO Auto-generated method stub
		
	}

}
