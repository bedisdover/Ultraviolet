package LEMS.po.storepo;

public enum LoadFormat {
	火车,
	飞机,
	汽车
}
