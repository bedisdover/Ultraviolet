package LEMS.businesslogic.orderbl;

import LEMS.businesslogicservice.orderblservice.ReceiptService;
import LEMS.vo.ordervo.ArrivalVO;

/**
 * @author 宋益明
 * 
 * 接收任务
 */
public class Receipt implements ReceiptService {

	public void addOrder(long id) {
		// TODO Auto-generated method stub
		
	}

	public void createArrivalNote(ArrivalVO arrivalInfo) {
		// TODO Auto-generated method stub
		
	}

}
