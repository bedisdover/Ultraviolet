package LEMS.businesslogicservice.inquireblservice;

import LEMS.vo.inquirevo.LogisticsInfoVO;

/**
 * @author 章承尧
 * 查询物流信息接口
 */
public interface InquireLogisticsInfoService {
	public LogisticsInfoVO getInquireLogisticsInfo();
}
