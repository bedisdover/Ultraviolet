package LEMS.data.inquiredata;

import LEMS.dataservice.inquiredataservice.DiaryDataService;
import LEMS.po.inquirepo.DiaryPO;

public class DiaryData implements DiaryDataService {

	public DiaryPO findDiary(String date) {
		// TODO Auto-generated method stub
		return null;
	}

}
