package LEMS.po.storepo;

public enum Destination {
北京,
上海,
广州,
南京
}
