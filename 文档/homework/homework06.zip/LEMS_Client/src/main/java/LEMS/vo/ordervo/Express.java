package LEMS.vo.ordervo;

/**
 * @author 宋益明
 * 快递类型:经济、标准、特快
 */
public enum Express {
	economy,//经济
	standard,//标准
	special//特快
}
