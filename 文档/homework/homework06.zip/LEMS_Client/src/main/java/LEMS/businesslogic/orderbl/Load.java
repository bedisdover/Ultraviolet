package LEMS.businesslogic.orderbl;

import LEMS.businesslogicservice.orderblservice.LoadService;
import LEMS.vo.ordervo.LoadVO;

/**
 * @author 宋益明
 * 
 * 装运管理任务
 */
public class Load implements LoadService {

	public void addOrder(long id) {
		// TODO Auto-generated method stub
		
	}

	public void createLoadNote(LoadVO loadInfo) {
		// TODO Auto-generated method stub
		
	}

}
