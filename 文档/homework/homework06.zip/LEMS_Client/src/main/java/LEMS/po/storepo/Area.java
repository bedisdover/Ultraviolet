package LEMS.po.storepo;

public enum Area{
	航运区,
	铁运区,
	汽运区,
	机动区
	}
