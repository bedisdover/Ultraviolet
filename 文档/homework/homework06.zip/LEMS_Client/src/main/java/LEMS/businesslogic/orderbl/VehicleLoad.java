package LEMS.businesslogic.orderbl;

import LEMS.businesslogicservice.orderblservice.VehicleLoadService;
import LEMS.vo.ordervo.VehicleLoadVO;

/**
 * @author 宋益明
 * 
 * 车辆装车管理任务
 */
public class VehicleLoad implements VehicleLoadService {

	public void addOrder(long id) {
		// TODO Auto-generated method stub
		
	}

	public void createVehicleLoadNote(VehicleLoadVO vehicleLoadVO) {
		// TODO Auto-generated method stub
		
	}

}
