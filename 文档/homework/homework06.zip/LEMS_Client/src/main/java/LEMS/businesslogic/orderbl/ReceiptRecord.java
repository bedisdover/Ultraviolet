package LEMS.businesslogic.orderbl;

import LEMS.businesslogicservice.orderblservice.ReceiptRecordService;
import LEMS.vo.ordervo.IncomeBillVO;

/**
 * @author 宋益明
 * 
 * 记录收款单任务
 */
public class ReceiptRecord implements ReceiptRecordService {

	public void addOrder(long id) {
		// TODO Auto-generated method stub
		
	}

	public void createIncomeBill(IncomeBillVO income) {
		// TODO Auto-generated method stub
		
	}

}
