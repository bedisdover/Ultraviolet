package LEMS.businesslogic.userbl;

import LEMS.po.userpo.UserRole;
import LEMS.vo.uservo.UserVO;

public class UserLogin {
	public UserVO login(long id,String password,String name,UserRole role){
		return null;
	}
}
