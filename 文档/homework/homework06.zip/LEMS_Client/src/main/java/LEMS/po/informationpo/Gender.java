package LEMS.po.informationpo;

public enum Gender{
    MAN, WOMEN;
}