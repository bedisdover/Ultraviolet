package LEMS.businesslogicservice.informationblservice;

/**
 * @author 苏琰梓
 * 结束此次信息管理
 * 2015年10月25日
 */
public interface InformationeEndManagementService {
	
	public void endManagement();
}
