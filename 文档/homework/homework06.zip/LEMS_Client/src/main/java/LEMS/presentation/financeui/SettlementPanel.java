package LEMS.presentation.financeui;

/**
 * @author 宋益明
 * 
 * 结算管理界面
 */
public class SettlementPanel {

}
