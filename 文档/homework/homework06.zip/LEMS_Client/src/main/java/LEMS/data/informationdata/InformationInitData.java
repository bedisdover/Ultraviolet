package LEMS.data.informationdata;

import java.rmi.RemoteException;

public class InformationInitData {
	public void init() throws RemoteException{
		
	}
}
