package LEMS.businesslogic.inquirebl;

import LEMS.businesslogicservice.inquireblservice.InquireCostBenefitListService;
import LEMS.vo.inquirevo.CostBenefitListVO;

/**
 * @author 章承尧
 * inquireCostBenefitListService接口的实现
 */
public class InquireCostBenefitList implements InquireCostBenefitListService {

	public CostBenefitListVO getCostBenefitList(String startTime, String endTime) {
		// TODO Auto-generated method stub
		return null;
	}

}
