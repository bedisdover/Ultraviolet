package LEMS.businesslogic.financebl;

import LEMS.businesslogicservice.financeblservice.NumericalStatementService;

/**
 * @author 宋益明
 * 
 * 统计报表任务
 */
public class NumericalStatement implements NumericalStatementService {

	public void export(long id) {
		// TODO Auto-generated method stub
		
	}

}
