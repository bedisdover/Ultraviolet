package LEMS.data.informationdata;

import java.rmi.RemoteException;

import LEMS.po.informationpo.DriverPO;
import LEMS.po.informationpo.InstitutionPO;
import LEMS.po.informationpo.StuffPO;
import LEMS.po.informationpo.VehiclePO;

/**
 * @author 苏琰梓
 * InformationUpdate包数据
 * 2015年10月26日
 */
public class InformationUpdateData {
	public void updateDriverPO(long id) throws RemoteException{
		
	}
	public void updateVehiclePO(long id) throws RemoteException{
		
	}
	public void updateInstitutionPO(String id) throws RemoteException{
		
	}
	public void updateStuffPO(String id) throws RemoteException{
		
	}
}
