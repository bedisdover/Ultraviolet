package LEMS.data.informationdata;

import java.rmi.RemoteException;

import LEMS.po.informationpo.DriverPO;
import LEMS.po.informationpo.InstitutionPO;
import LEMS.po.informationpo.StuffPO;
import LEMS.po.informationpo.VehiclePO;

/**
 * @author 苏琰梓
 * InformationUpdate包数据
 * 2015年10月26日
 */
public class InformationUpdateData {
	public void update(DriverPO po) throws RemoteException{
		
	}
	public void update(VehiclePO po) throws RemoteException{
		
	}
	public void update(InstitutionPO po) throws RemoteException{
		
	}
	public void update(StuffPO po) throws RemoteException{
		
	}
}
