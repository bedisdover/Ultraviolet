package LEMS.businesslogic.storebl;

import LEMS.businesslogicservice.storeblservice.StoreGenerateOrderService;
import LEMS.po.storepo.InboundOrderPO;
import LEMS.po.storepo.OutboundOrderPO;
import LEMS.vo.storevo.InboundOrderVO;
import LEMS.vo.storevo.OutboundOrderVO;

public class StoreGenerateOrder implements  StoreGenerateOrderService{

	public InboundOrderVO generateInboundOrder(InboundOrderPO inboundOrderPO){
		// TODO Auto-generated method stub
		return null;
	
}
	
	public OutboundOrderVO generateOutboundOrder(OutboundOrderPO outboundOrderPO){
		// TODO Auto-generated method stub
		return null;
		
	}
}
