package LEMS.presentation.financeui;

import javax.swing.JPanel;

/**
 * @author 宋益明
 * 
 * 结算管理任务界面
 */
public class CostPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
