package LEMS.vo.informationvo;

public enum Gender{
    MAN, WOMEN;
}
