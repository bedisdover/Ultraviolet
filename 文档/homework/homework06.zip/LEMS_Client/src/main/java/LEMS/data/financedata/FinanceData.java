package LEMS.data.financedata;

import java.rmi.RemoteException;

import LEMS.dataservice.financedataservice.FinanceDataService;
import LEMS.po.financepo.FinancePO;

/**
 * @author 宋益明
 * 
 * Finance包数据
 */
public class FinanceData implements FinanceDataService {

	public FinancePO find(long id) throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	public void insert(FinancePO po) throws RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void delete(FinancePO po) throws RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void update(FinancePO po) throws RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void init() throws RemoteException {
		// TODO Auto-generated method stub
		
	}

	public void finish() throws RemoteException {
		// TODO Auto-generated method stub
		
	}

}
