package LEMS.businesslogic.financebl;

import LEMS.businesslogicservice.financeblservice.ApprovalService;
import LEMS.vo.financevo.DocumentVO;

/**
 * @author 宋益明
 * 
 * 审批单据任务
 */
public class Approval implements ApprovalService {

	public void accepted(DocumentVO document) {
		// TODO Auto-generated method stub
		
	}

	public void unaccepted(DocumentVO document) {
		// TODO Auto-generated method stub
		
	}

}
