package LEMS.vo.ordervo;

/**
 * @author 宋益明
 * 
 * 运输方式：飞机、火车、汽车
 */
public enum TransportType {
	airplane,//飞机
	railway,//火车
	landway//汽车
}
