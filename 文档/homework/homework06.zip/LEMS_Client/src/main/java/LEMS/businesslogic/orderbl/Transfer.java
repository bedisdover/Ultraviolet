package LEMS.businesslogic.orderbl;

import LEMS.businesslogicservice.orderblservice.TransferService;
import LEMS.vo.ordervo.TransferVO;

/**
 * @author 宋益明
 * 
 * 中转接收任务
 */
public class Transfer implements TransferService {

	public void createTransferNote(TransferVO transferInfo) {
		// TODO Auto-generated method stub
		
	}

	public void addOrder(long id) {
		// TODO Auto-generated method stub
		
	}

}
