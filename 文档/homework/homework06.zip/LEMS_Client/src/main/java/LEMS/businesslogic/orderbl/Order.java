package LEMS.businesslogic.orderbl;

import LEMS.businesslogicservice.orderblservice.OrderService;
import LEMS.vo.ordervo.Express;
import LEMS.vo.ordervo.GoodsVO;
import LEMS.vo.ordervo.ReceiverVO;
import LEMS.vo.ordervo.SenderVO;

/**
 * @author 宋益明
 * 
 * 新建订单任务
 */
public class Order implements OrderService {

	public void addSender(SenderVO sender) {
		// TODO Auto-generated method stub
		
	}

	public void addReceiver(ReceiverVO receiver) {
		// TODO Auto-generated method stub
		
	}

	public void addGoodsInfo(GoodsVO goods) {
		// TODO Auto-generated method stub
		
	}

	public void chooseType(Express type) {
		// TODO Auto-generated method stub
		
	}

	public long createID() {
		// TODO Auto-generated method stub
		return 0;
	}

	public double getMoney() {
		// TODO Auto-generated method stub
		return 0;
	}

	public double getTotal() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getTime() {
		// TODO Auto-generated method stub
		return null;
	}

	public void endOrder() {
		// TODO Auto-generated method stub
		
	}

}
