package LEMS.businesslogic.financebl;

import LEMS.businesslogicservice.financeblservice.SettlementService;
import LEMS.vo.financevo.IncomeBillVO;

/**
 * @author 宋益明
 *
 * 结算管理任务
 */
public class Settlement implements SettlementService {

	public IncomeBillVO getIncomeInfo(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void addIncomeInfo(IncomeBillVO income) {
		// TODO Auto-generated method stub
		
	}

	public void incomeBill() {
		// TODO Auto-generated method stub
		
	}

}
