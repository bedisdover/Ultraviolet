package LEMS.businesslogic.financebl;

import LEMS.businesslogicservice.financeblservice.PriceService;
import LEMS.vo.ordervo.Express;

/**
 * @author 宋益明
 * 
 * 制定价格任务
 */
public class Price implements PriceService {

	public double getPrice(Express type) {
		// TODO Auto-generated method stub
		return 0;
	}

	public void pricing(Express type, double price) {
		// TODO Auto-generated method stub
		
	}

}
