package LEMS.data.userdata;

import java.rmi.RemoteException;

import LEMS.po.userpo.UserPO;

public class UserData {

	public void getUserDatabase(UserPO po) throws RemoteException{
		
	}
	public void delete(UserPO po) throws RemoteException{
		
	}
	public void update(UserPO po) throws RemoteException{
		
	}
	public UserPO find(long id) throws RemoteException{
		return null;
	}
}